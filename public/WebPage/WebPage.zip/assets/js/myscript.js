$('input[name="dates"]'). daterangepicker();



function abrir_modal(){
    $("#exampleModal").modal("show")
}

function cerrar_modal(){
    $("#exampleModal").modal("hide")
}